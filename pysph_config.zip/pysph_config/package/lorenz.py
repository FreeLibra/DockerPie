from scipy.integrate import odeint
import numpy as np


def lorenz(w, t, p, r, b):
    x, y, z = w
    return np.array([p * (y - x), x * (r - z) - y, x * y - b * z])


t = np.arange(0, 30, 0.01)
track1 = odeint(lorenz, (0.0, 1.00, 0.0), t, args=(10.0, 28.0, 3.0))

from mayavi import mlab

X, Y, Z = track1.T

mlab.plot3d(X, Y, Z, t, tube_radius=0.2)
mlab.show()